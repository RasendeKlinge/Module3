def print_params(a=1, b='Cтрока', c=True):
    print(a, b, c)


print_params()
print_params(5, 'pyramid', False)
print_params(466, 'honda')
print_params(b='moto')
print_params(b=25)
print_params(c=[1, 2, 3])

values_list = [458, 'Kia', False]
values_dict = {'a': 500, 'b': 'Spectra', 'c': True}
print_params(*values_list)
print_params(**values_dict)

values_list_2 = [3.14, 'programmer']
print_params(*values_list_2, 42)
